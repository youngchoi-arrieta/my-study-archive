'use client'

import type { BlankAnswer, ContactType } from '@/types/trainer'
import { getSymSvg, TYPE_LABEL } from '@/lib/trainer/symbols'

interface Props {
  palette: BlankAnswer[]
  selectedId: string | null
  onSelect: (a: BlankAnswer) => void
  userAnswer?: BlankAnswer
}

const TYPE_COLOR: Record<ContactType, { bg: string; border: string; text: string; selBg: string }> = {
  NO:   { bg: '#f0fdf4', border: '#86efac', text: '#15803d', selBg: '#dcfce7' },
  NC:   { bg: '#fffbeb', border: '#fcd34d', text: '#b45309', selBg: '#fef3c7' },
  tNO:  { bg: '#eff6ff', border: '#93c5fd', text: '#1d4ed8', selBg: '#dbeafe' },
  tNC:  { bg: '#faf5ff', border: '#c4b5fd', text: '#7c3aed', selBg: '#ede9fe' },
  coil: { bg: '#fff1f2', border: '#fda4af', text: '#be123c', selBg: '#ffe4e6' },
}

export default function Palette({ palette, selectedId, onSelect, userAnswer }: Props) {
  return (
    <div style={{
      padding: '10px 14px',
      borderTop: '1px solid #e5e7eb',
      background: '#f9fafb',
      flexShrink: 0,
    }}>
      {!selectedId ? (
        <p style={{ fontSize: 11, color: '#9ca3af', fontFamily: 'var(--font-sans)' }}>
          도면의 빈칸(?)을 클릭하세요
        </p>
      ) : (
        <>
          <p style={{ fontSize: 11, color: '#374151', marginBottom: 8, fontFamily: 'var(--font-sans)', fontWeight: 500 }}>
            접점 선택
            {userAnswer && (
              <span style={{ marginLeft: 8, color: '#16a34a', fontWeight: 700 }}>
                ✓ {userAnswer.label} {TYPE_LABEL[userAnswer.type]}
              </span>
            )}
          </p>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {palette.map((a, i) => {
              const c = TYPE_COLOR[a.type]
              const isSelected = userAnswer?.label === a.label && userAnswer?.type === a.type
              return (
                <button
                  key={i}
                  onClick={() => onSelect(a)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 5,
                    padding: '5px 10px',
                    border: `1.5px solid ${isSelected ? '#16a34a' : c.border}`,
                    borderRadius: 6,
                    background: isSelected ? '#dcfce7' : c.bg,
                    cursor: 'pointer',
                    color: c.text,
                    transition: 'all .1s',
                    boxShadow: isSelected ? '0 0 0 2px #bbf7d0' : 'none',
                  }}
                >
                  <div
                    dangerouslySetInnerHTML={{ __html: getSymSvg(a.type) }}
                    style={{ color: c.text, transform: 'scale(0.6)', transformOrigin: 'left center', width: 28, height: 18, overflow: 'hidden' }}
                  />
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', lineHeight: 1.2 }}>
                    <span style={{ fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-mono)' }}>
                      {a.label}
                    </span>
                    <span style={{ fontSize: 9, fontFamily: 'var(--font-sans)', color: c.text, opacity: 0.75 }}>
                      {TYPE_LABEL[a.type]}
                    </span>
                  </div>
                </button>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}
