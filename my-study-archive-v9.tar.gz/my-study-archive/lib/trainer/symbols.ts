import type { ContactType } from '@/types/trainer'

const S = 'currentColor'
const W = '1.8'

export function symNO() {
  return `<svg viewBox="0 0 44 28" width="44" height="28"><line x1="0" y1="14" x2="12" y2="14" stroke="${S}" stroke-width="${W}"/><line x1="12" y1="4" x2="12" y2="24" stroke="${S}" stroke-width="${W}"/><line x1="32" y1="4" x2="32" y2="24" stroke="${S}" stroke-width="${W}"/><line x1="32" y1="14" x2="44" y2="14" stroke="${S}" stroke-width="${W}"/></svg>`
}
export function symNC() {
  return `<svg viewBox="0 0 44 28" width="44" height="28"><line x1="0" y1="14" x2="12" y2="14" stroke="${S}" stroke-width="${W}"/><line x1="12" y1="4" x2="12" y2="24" stroke="${S}" stroke-width="${W}"/><line x1="32" y1="4" x2="32" y2="24" stroke="${S}" stroke-width="${W}"/><line x1="32" y1="14" x2="44" y2="14" stroke="${S}" stroke-width="${W}"/><line x1="12" y1="5" x2="32" y2="23" stroke="${S}" stroke-width="${W}"/></svg>`
}
export function symTNO() {
  return `<svg viewBox="0 0 44 28" width="44" height="28"><line x1="0" y1="14" x2="12" y2="14" stroke="${S}" stroke-width="${W}"/><line x1="12" y1="4" x2="12" y2="24" stroke="${S}" stroke-width="${W}"/><line x1="32" y1="4" x2="32" y2="24" stroke="${S}" stroke-width="${W}"/><line x1="32" y1="14" x2="44" y2="14" stroke="${S}" stroke-width="${W}"/><path d="M17 4 Q22 0 27 4" stroke="${S}" stroke-width="1.3" fill="none"/></svg>`
}
export function symTNC() {
  return `<svg viewBox="0 0 44 28" width="44" height="28"><line x1="0" y1="14" x2="12" y2="14" stroke="${S}" stroke-width="${W}"/><line x1="12" y1="4" x2="12" y2="24" stroke="${S}" stroke-width="${W}"/><line x1="32" y1="4" x2="32" y2="24" stroke="${S}" stroke-width="${W}"/><line x1="32" y1="14" x2="44" y2="14" stroke="${S}" stroke-width="${W}"/><line x1="12" y1="5" x2="32" y2="23" stroke="${S}" stroke-width="${W}"/><path d="M17 4 Q22 0 27 4" stroke="${S}" stroke-width="1.3" fill="none"/></svg>`
}
export function symCoil() {
  return `<svg viewBox="0 0 44 28" width="44" height="28"><line x1="0" y1="14" x2="10" y2="14" stroke="${S}" stroke-width="${W}"/><circle cx="22" cy="14" r="11" stroke="${S}" stroke-width="${W}" fill="none"/><line x1="34" y1="14" x2="44" y2="14" stroke="${S}" stroke-width="${W}"/></svg>`
}

export function getSymSvg(type: ContactType): string {
  switch (type) {
    case 'NO':   return symNO()
    case 'NC':   return symNC()
    case 'tNO':  return symTNO()
    case 'tNC':  return symTNC()
    case 'coil': return symCoil()
    default:     return ''
  }
}

export const TYPE_LABEL: Record<ContactType, string> = {
  NO:   'a접점',
  NC:   'b접점',
  tNO:  '한시a',
  tNC:  '한시b',
  coil: '코일',
}
