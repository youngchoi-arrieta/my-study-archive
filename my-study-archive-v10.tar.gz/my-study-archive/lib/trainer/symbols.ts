import type { ContactType } from '@/types/trainer'

// 실제 KS 시퀀스 회로도 심볼 — 크고 명확하게
// viewBox 60x40, 수평 방향 (접점이 선 위에 위치)

export function symNO(color = 'currentColor') {
  // a접점: 양쪽 수직선, 사이에 열린 간격
  return `<svg viewBox="0 0 60 40" width="60" height="40">
    <line x1="0" y1="20" x2="18" y2="20" stroke="${color}" stroke-width="2"/>
    <line x1="18" y1="8" x2="18" y2="32" stroke="${color}" stroke-width="2"/>
    <line x1="42" y1="8" x2="42" y2="32" stroke="${color}" stroke-width="2"/>
    <line x1="42" y1="20" x2="60" y2="20" stroke="${color}" stroke-width="2"/>
  </svg>`
}

export function symNC(color = 'currentColor') {
  // b접점: a접점 + 대각선
  return `<svg viewBox="0 0 60 40" width="60" height="40">
    <line x1="0" y1="20" x2="18" y2="20" stroke="${color}" stroke-width="2"/>
    <line x1="18" y1="8" x2="18" y2="32" stroke="${color}" stroke-width="2"/>
    <line x1="42" y1="8" x2="42" y2="32" stroke="${color}" stroke-width="2"/>
    <line x1="42" y1="20" x2="60" y2="20" stroke="${color}" stroke-width="2"/>
    <line x1="18" y1="9" x2="42" y2="31" stroke="${color}" stroke-width="2"/>
  </svg>`
}

export function symTNO(color = 'currentColor') {
  // 한시 a접점: a접점 + 상단 호
  return `<svg viewBox="0 0 60 40" width="60" height="40">
    <line x1="0" y1="20" x2="18" y2="20" stroke="${color}" stroke-width="2"/>
    <line x1="18" y1="8" x2="18" y2="32" stroke="${color}" stroke-width="2"/>
    <line x1="42" y1="8" x2="42" y2="32" stroke="${color}" stroke-width="2"/>
    <line x1="42" y1="20" x2="60" y2="20" stroke="${color}" stroke-width="2"/>
    <path d="M22 8 Q30 2 38 8" stroke="${color}" stroke-width="2" fill="none"/>
  </svg>`
}

export function symTNC(color = 'currentColor') {
  // 한시 b접점: b접점 + 상단 호
  return `<svg viewBox="0 0 60 40" width="60" height="40">
    <line x1="0" y1="20" x2="18" y2="20" stroke="${color}" stroke-width="2"/>
    <line x1="18" y1="8" x2="18" y2="32" stroke="${color}" stroke-width="2"/>
    <line x1="42" y1="8" x2="42" y2="32" stroke="${color}" stroke-width="2"/>
    <line x1="42" y1="20" x2="60" y2="20" stroke="${color}" stroke-width="2"/>
    <line x1="18" y1="9" x2="42" y2="31" stroke="${color}" stroke-width="2"/>
    <path d="M22 8 Q30 2 38 8" stroke="${color}" stroke-width="2" fill="none"/>
  </svg>`
}

export function symCoil(color = 'currentColor') {
  // 코일: 원
  return `<svg viewBox="0 0 60 40" width="60" height="40">
    <line x1="0" y1="20" x2="14" y2="20" stroke="${color}" stroke-width="2"/>
    <circle cx="30" cy="20" r="14" stroke="${color}" stroke-width="2" fill="none"/>
    <line x1="46" y1="20" x2="60" y2="20" stroke="${color}" stroke-width="2"/>
  </svg>`
}

export function getSymSvg(type: ContactType, color = 'currentColor'): string {
  switch (type) {
    case 'NO':   return symNO(color)
    case 'NC':   return symNC(color)
    case 'tNO':  return symTNO(color)
    case 'tNC':  return symTNC(color)
    case 'coil': return symCoil(color)
    default:     return ''
  }
}

export const TYPE_LABEL: Record<ContactType, string> = {
  NO:   'a접점',
  NC:   'b접점',
  tNO:  '한시a',
  tNC:  '한시b',
  coil: '코일',
}
